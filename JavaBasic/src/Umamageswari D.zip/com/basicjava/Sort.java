package com.basicjava;

import java.util.Arrays;

public class Sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = { 2, 4, 1, 3, 5 };
		String b[] = {"a","c","e","b","d"};
		Arrays.sort(a);
		Arrays.sort(b);
		System.out.println("numeric array of:" +Arrays.toString(a));
		System.out.println("string array of:" +Arrays.toString(b));
		
		

	}

}
