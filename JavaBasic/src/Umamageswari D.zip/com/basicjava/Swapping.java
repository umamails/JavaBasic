package com.basicjava;

public class Swapping {
	public static void main(String[] args) {
		int a = 4;
		int b = 3;
		int c;
		c = a;
		a = b;
		b = c;
		System.out.println(a + "\n" + b);
	}

}
