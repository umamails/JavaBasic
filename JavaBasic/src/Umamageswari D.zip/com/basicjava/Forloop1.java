package com.basicjava;

public class Forloop1 extends Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 10;
		int i;
		for (i = 1; i <= n; i++) {
			System.out.println(+i);
		}

	}

}
