package com.basicjava;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 5;
		int sum = 0;
		for (int i = 1; i <= n; i++) {

			sum = sum + i;
		}
		System.out.println("the sum of first 5 natural number is:" + sum);
	}

}
