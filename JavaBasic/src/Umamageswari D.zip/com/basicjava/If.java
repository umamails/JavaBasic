package com.basicjava;

public class If {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b = 5;
		if (a > b) {
			System.out.println("a is greater than b \n");
		}
		System.out.println("End of the Program");

	}

}
