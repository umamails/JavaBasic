package com.basicjava;

public class Ifelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 5;
		int b = 10;
		if (a > b) {
			System.out.println("a is greater");
		} else {
			System.out.println("b is greater");
		}

		System.out.println("End of the Program");
	}

}
