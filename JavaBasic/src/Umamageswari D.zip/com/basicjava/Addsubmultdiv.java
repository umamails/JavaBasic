package com.basicjava;

public class Addsubmultdiv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10;
		int b = 2;
		System.out.println("Add =" + (a + b));
		System.out.println("Sub =" + (a - b));
		System.out.println("mult =" + (a * b));
		System.out.println("Div =" + (a / b));
		System.out.println("remainder =" + (a % b));
	}

}
