package com.basicjava;

public class Specificvalue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[] = { 2, 4, 1, 3, 5 };
		// int size[] = new int [5];
		for (int i = 0; i < 5; i++) {
			// a[i]= i;
			if (a[i] == 5)

				System.out.println("Array of sepcific no. is:" + a[i]);

		}

	}

}
