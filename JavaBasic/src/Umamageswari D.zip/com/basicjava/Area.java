package com.basicjava;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int width = 2;
		int height = 3;
		System.out.println(" Print the area = " + (width * height));
		System.out.println("Perimeter of a rectangle = " + 2 * (width + height));
	}

}
