package com.basicjava;

public class Stars {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
// reverse the star
		for (int i=4; i>0; i--) {
			for(int j=1; j<=i; j++) {
				System.out.println("*");
			}
			System.out.println();
		}
	}

}
